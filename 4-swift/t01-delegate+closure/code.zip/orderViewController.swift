//
//  orderViewController.swift
//  t02
//
//  Created by ethan on 2020/6/13.
//  Copyright © 2020 ethan. All rights reserved.
//

import UIKit

@objc protocol OrderViewDelegate {
    func sendOrder(myOrder: drink)
}

class orderViewController: UIViewController {
    var myDrink: drink!
    weak var delegate: OrderViewDelegate?
    
    @IBOutlet var nameTextField: UITextField!
    @IBOutlet var sweetSelect: UISegmentedControl!
    @IBOutlet var iceSelect: UISegmentedControl!
    @IBOutlet var priceTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if (myDrink != nil) {
            nameTextField.text = myDrink.name
            sweetSelect.selectedSegmentIndex = myDrink.sweetSelectIndex
            iceSelect.selectedSegmentIndex = myDrink.iceSelectIndex
            priceTextField.text = "\(myDrink.price)"
        }
    }
    
    @IBAction func sendBtnClick(_ sender: Any) {
        if (myDrink == nil) {
            myDrink = drink()
        }
        
        myDrink.name = nameTextField.text ?? ""
        myDrink.sweetSelectIndex = sweetSelect.selectedSegmentIndex
        myDrink.sweetness = sweetSelect.titleForSegment(at: sweetSelect.selectedSegmentIndex)!
        myDrink.iceSelectIndex = iceSelect.selectedSegmentIndex
        myDrink.ice = iceSelect.titleForSegment(at: iceSelect.selectedSegmentIndex)!
        myDrink.price = Int(priceTextField.text!) ?? 0
        delegate?.sendOrder(myOrder: myDrink)
        
        navigationController?.popViewController(animated: true)
    }
}
